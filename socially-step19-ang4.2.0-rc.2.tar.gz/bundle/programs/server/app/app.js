var require = meteorInstall({"server":{"imports":{"fixtures":{"parties.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/imports/fixtures/parties.js                                                                    //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
var parties_collection_1 = require("../../../both/collections/parties.collection");                      // 1
function loadParties() {                                                                                 // 4
    if (parties_collection_1.Parties.find().cursor.count() === 0) {                                      //
        var parties = [{                                                                                 //
                name: 'Dubstep-Free Zone',                                                               //
                description: 'Can we please just for an evening not listen to dubstep.',                 //
                location: {                                                                              //
                    name: 'Palo Alto'                                                                    //
                },                                                                                       //
                public: true                                                                             //
            }, {                                                                                         //
                name: 'All dubstep all the time',                                                        //
                description: 'Get it on!',                                                               //
                location: {                                                                              //
                    name: 'Palo Alto'                                                                    //
                },                                                                                       //
                public: true                                                                             //
            }, {                                                                                         //
                name: 'Savage lounging',                                                                 //
                description: 'Leisure suit required. And only fiercest manners.',                        //
                location: {                                                                              //
                    name: 'San Francisco'                                                                //
                },                                                                                       //
                public: false                                                                            //
            }];                                                                                          //
        parties.forEach(function (party) { return parties_collection_1.Parties.insert(party); });        //
    }                                                                                                    //
}                                                                                                        // 31
exports.loadParties = loadParties;                                                                       // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"parties.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/imports/publications/parties.js                                                                //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
var meteor_1 = require("meteor/meteor");                                                                 // 1
var tmeasday_publish_counts_1 = require("meteor/tmeasday:publish-counts");                               // 2
var parties_collection_1 = require("../../../both/collections/parties.collection");                      // 4
meteor_1.Meteor.publish('parties', function (options, location) {                                        // 10
    var selector = buildQuery.call(this, null, location);                                                //
    tmeasday_publish_counts_1.Counts.publish(this, 'numberOfParties', parties_collection_1.Parties.collection.find(selector), { noReady: true });
    return parties_collection_1.Parties.find(selector, options);                                         //
});                                                                                                      // 16
meteor_1.Meteor.publish('party', function (partyId) {                                                    // 18
    return parties_collection_1.Parties.find(buildQuery.call(this, partyId));                            //
});                                                                                                      // 20
function buildQuery(partyId, location) {                                                                 // 23
    var isAvailable = {                                                                                  //
        $or: [{                                                                                          //
                // party is public                                                                       //
                public: true                                                                             //
            },                                                                                           //
            // or                                                                                        //
            {                                                                                            //
                // current user is the owner                                                             //
                $and: [{                                                                                 //
                        owner: this.userId                                                               //
                    }, {                                                                                 //
                        owner: {                                                                         //
                            $exists: true                                                                //
                        }                                                                                //
                    }]                                                                                   //
            },                                                                                           //
            {                                                                                            //
                $and: [                                                                                  //
                    { invited: this.userId },                                                            //
                    { invited: { $exists: true } }                                                       //
                ]                                                                                        //
            }]                                                                                           //
    };                                                                                                   //
    if (partyId) {                                                                                       //
        return {                                                                                         //
            // only single party                                                                         //
            $and: [{                                                                                     //
                    _id: partyId                                                                         //
                },                                                                                       //
                isAvailable                                                                              //
            ]                                                                                            //
        };                                                                                               //
    }                                                                                                    //
    var searchRegEx = { '$regex': '.*' + (location || '') + '.*', '$options': 'i' };                     //
    return {                                                                                             //
        $and: [{                                                                                         //
                'location.name': searchRegEx                                                             //
            },                                                                                           //
            isAvailable                                                                                  //
        ]                                                                                                //
    };                                                                                                   //
}                                                                                                        // 68
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/imports/publications/users.js                                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
var meteor_1 = require("meteor/meteor");                                                                 // 1
var parties_collection_1 = require("../../../both/collections/parties.collection");                      // 3
meteor_1.Meteor.publish('uninvited', function (partyId) {                                                // 5
    var party = parties_collection_1.Parties.findOne(partyId);                                           //
    if (!party) {                                                                                        //
        throw new meteor_1.Meteor.Error('404', 'No such party!');                                        //
    }                                                                                                    //
    return meteor_1.Meteor.users.find({                                                                  //
        _id: {                                                                                           //
            $nin: party.invited || [],                                                                   //
            $ne: this.userId                                                                             //
        }                                                                                                //
    });                                                                                                  //
});                                                                                                      // 18
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"main.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/main.js                                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
var meteor_1 = require("meteor/meteor");                                                                 // 1
var parties_1 = require("/server/imports/fixtures/parties");                                             // 3
require("/server/imports/publications/parties");                                                         // 5
require("/server/imports/publications/users");                                                           // 6
require("../both/methods/parties.methods");                                                              // 7
meteor_1.Meteor.startup(function () {                                                                    // 9
    parties_1.loadParties();                                                                             //
});                                                                                                      // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"both":{"collections":{"parties.collection.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// both/collections/parties.collection.js                                                                //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
var meteor_rxjs_1 = require("meteor-rxjs");                                                              // 1
var meteor_1 = require("meteor/meteor");                                                                 // 2
exports.Parties = new meteor_rxjs_1.MongoObservable.Collection('parties');                               // 6
function loggedIn() {                                                                                    // 8
    return !!meteor_1.Meteor.user();                                                                     //
}                                                                                                        // 10
exports.Parties.allow({                                                                                  // 12
    insert: loggedIn,                                                                                    //
    update: loggedIn,                                                                                    //
    remove: loggedIn                                                                                     //
});                                                                                                      //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.collection.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// both/collections/users.collection.js                                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
var meteor_rxjs_1 = require("meteor-rxjs");                                                              // 1
var meteor_1 = require("meteor/meteor");                                                                 // 2
exports.Users = meteor_rxjs_1.MongoObservable.fromExisting(meteor_1.Meteor.users);                       // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"parties.methods.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// both/methods/parties.methods.js                                                                       //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
var parties_collection_1 = require("/both/collections/parties.collection");                              // 1
var email_1 = require("meteor/email");                                                                   // 2
var check_1 = require("meteor/check");                                                                   // 3
var meteor_1 = require("meteor/meteor");                                                                 // 4
function getContactEmail(user) {                                                                         // 6
    if (user.emails && user.emails.length)                                                               //
        return user.emails[0].address;                                                                   //
    return null;                                                                                         //
}                                                                                                        // 11
meteor_1.Meteor.methods({                                                                                // 13
    invite: function (partyId, userId) {                                                                 //
        check_1.check(partyId, String);                                                                  //
        check_1.check(userId, String);                                                                   //
        var party = parties_collection_1.Parties.collection.findOne(partyId);                            //
        if (!party)                                                                                      //
            throw new meteor_1.Meteor.Error('404', 'No such party!');                                    //
        if (party.public)                                                                                //
            throw new meteor_1.Meteor.Error('400', 'That party is public. No need to invite people.');   //
        if (party.owner !== this.userId)                                                                 //
            throw new meteor_1.Meteor.Error('403', 'No permissions!');                                   //
        if (userId !== party.owner && (party.invited || []).indexOf(userId) == -1) {                     //
            parties_collection_1.Parties.collection.update(partyId, { $addToSet: { invited: userId } });
            var from = getContactEmail(meteor_1.Meteor.users.findOne(this.userId));                      //
            var to = getContactEmail(meteor_1.Meteor.users.findOne(userId));                             //
            if (meteor_1.Meteor.isServer && to) {                                                        //
                email_1.Email.send({                                                                     //
                    from: 'noreply@socially.com',                                                        //
                    to: to,                                                                              //
                    replyTo: from || undefined,                                                          //
                    subject: 'PARTY: ' + party.name,                                                     //
                    text: "Hi, I just invited you to " + party.name + " on Socially.\n                        \n\nCome check it out: " + meteor_1.Meteor.absoluteUrl() + "\n"
                });                                                                                      //
            }                                                                                            //
        }                                                                                                //
    },                                                                                                   //
    reply: function (partyId, rsvp) {                                                                    //
        var _this = this;                                                                                //
        check_1.check(partyId, String);                                                                  //
        check_1.check(rsvp, String);                                                                     //
        if (!this.userId)                                                                                //
            throw new meteor_1.Meteor.Error('403', 'You must be logged-in to reply');                    //
        if (['yes', 'no', 'maybe'].indexOf(rsvp) === -1)                                                 //
            throw new meteor_1.Meteor.Error('400', 'Invalid RSVP');                                      //
        var party = parties_collection_1.Parties.findOne({ _id: partyId });                              //
        if (!party)                                                                                      //
            throw new meteor_1.Meteor.Error('404', 'No such party');                                     //
        if (party.owner === this.userId)                                                                 //
            throw new meteor_1.Meteor.Error('500', 'You are the owner!');                                //
        if (!party.public && (!party.invited || party.invited.indexOf(this.userId) == -1))               //
            throw new meteor_1.Meteor.Error('403', 'No such party'); // its private, but let's not tell this to the user
        var rsvpIndex = party.rsvps ? party.rsvps.findIndex(function (rsvp) { return rsvp.userId === _this.userId; }) : -1;
        if (rsvpIndex !== -1) {                                                                          //
            // update existing rsvp entry                                                                //
            if (meteor_1.Meteor.isServer) {                                                              //
                // update the appropriate rsvp entry with $                                              //
                parties_collection_1.Parties.update({ _id: partyId, 'rsvps.userId': this.userId }, { $set: { 'rsvps.$.response': rsvp } });
            }                                                                                            //
            else {                                                                                       //
                // minimongo doesn't yet support $ in modifier. as a temporary                           //
                // workaround, make a modifier that uses an index. this is                               //
                // safe on the client since there's only one thread.                                     //
                var modifier = { $set: {} };                                                             //
                modifier.$set['rsvps.' + rsvpIndex + '.response'] = rsvp;                                //
                parties_collection_1.Parties.update(partyId, modifier);                                  //
            }                                                                                            //
        }                                                                                                //
        else {                                                                                           //
            // add new rsvp entry                                                                        //
            parties_collection_1.Parties.update(partyId, { $push: { rsvps: { userId: this.userId, response: rsvp } } });
        }                                                                                                //
    }                                                                                                    //
});                                                                                                      //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"collection-object.model.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// both/models/collection-object.model.js                                                                //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"party.model.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// both/models/party.model.js                                                                            //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"user.model.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// both/models/user.model.js                                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Object.defineProperty(exports, "__esModule", { value: true });                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json",
    ".html",
    ".ts",
    ".scss"
  ]
});
require("./both/collections/parties.collection.js");
require("./both/collections/users.collection.js");
require("./both/methods/parties.methods.js");
require("./both/models/collection-object.model.js");
require("./both/models/party.model.js");
require("./both/models/user.model.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
